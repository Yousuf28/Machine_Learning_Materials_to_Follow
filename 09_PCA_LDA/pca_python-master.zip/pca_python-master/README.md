PCA Places Rated

Principle component analysis using python and numpy. 
Although there are better methods such as PCA() class from the matplotlib.mlab to 
do PCA. This code is meant to provide the first hand experiance of step by step working 
of PCA calculation.  

USAGE: 
	
	python places_pca.py -m <log/unit> -c <column number> -e <no of eigenvalues>

For help:

	python places_pca.py -h

This program perform PCA on Places Rated Almanac data.
The Places Rated Almanac data (Boyer and Savageau) which rates 329 communities according to nine criteria:

Climate and Terrain
Housing
Health Care & Environment
Crime
Transportation
Education
The Arts
Recreation
Economics

Additionally coloumns are 

CaseNum	
Long
Lat
Pop
StNum
 
